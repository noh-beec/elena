import React from 'react';

const Footer = (props) => {
    return (
       <>
       <h3>Footer</h3>
       </>
    )
}

export default Footer