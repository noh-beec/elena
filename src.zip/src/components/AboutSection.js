import React from 'react';

const AboutSection = (props) => {
    return (
       <>
       <h3>Aqui va el acerca de. En construccion</h3>
       </>
    )
}

export default AboutSection