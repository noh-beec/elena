import React from 'react';

const FaqSection = (props) => {
    return (
       <>
       <h3>Aqui van las preguntas frecuentes</h3>
       </>
    )
}

export default FaqSection