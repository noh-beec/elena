import React from 'react';

const ContactSection = (props) => {
    return (
       <>
       <h3>Aqui va el formulario de contacto</h3>
       </>
    )
}

export default ContactSection