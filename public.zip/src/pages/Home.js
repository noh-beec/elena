import React from 'react';
import Seccion1 from '../components/Seccion1';

const Home = (props) => {
    return (
        <>
         <Seccion1></Seccion1>
        </>
    )
}

export default Home;